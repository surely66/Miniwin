/* cairommconfig.h.  Generated from cairommconfig.h.in by configure.  */
/* This file is part of cairomm. */

/* Defined when the --enable-api-exceptions configure argument was given */
#define CAIROMM_EXCEPTIONS_ENABLED 1

/* Major version number of cairomm. */
#define CAIROMM_MAJOR_VERSION 1

/* Minor version number of cairomm. */
#define CAIROMM_MINOR_VERSION 12

/* Micro version number of cairomm. */
#define CAIROMM_MICRO_VERSION 2
